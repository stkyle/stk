//
// Created by root on 11/27/17.
//

#include "util.h"
#include <unistd.h>
#include <stdio.h> // perror
#include <stdlib.h>
#include <time.h>

bool isfile(const char *filename){
    return (bool) ( access( filename, F_OK ) != -1 );
}

bool isreadable(const char *filename){
    return (bool) ( access( filename, R_OK ) != -1 );
}

void handle_error(const char *msg){
    // do something with error
    printf(msg);
}

#include <stdio.h>

void hexDump (char *desc, void *addr, int len) {
    int i;
    unsigned char buff[17];
    unsigned char *pc = (unsigned char*)addr;

    // Output description if given.
    if (desc != NULL)
        printf ("%s:\n", desc);

    if (len == 0) {
        printf("  ZERO LENGTH\n");
        return;
    }
    if (len < 0) {
        printf("  NEGATIVE LENGTH: %i\n",len);
        return;
    }

    // Process every byte in the data.
    for (i = 0; i < len; i++) {
        // Multiple of 16 means new line (with line offset).

        if ((i % 16) == 0) {
            // Just don't print ASCII for the zeroth line.
            if (i != 0)
                printf ("  %s\n", buff);

            // Output the offset.
            printf ("  %04x ", i);
        }

        // Now the hex code for the specific character.
        printf (" %02x", pc[i]);

        // And store a printable ASCII character for later.
        if ((pc[i] < 0x20) || (pc[i] > 0x7e))
            buff[i % 16] = '.';
        else
            buff[i % 16] = pc[i];
        buff[(i % 16) + 1] = '\0';
    }

    // Pad out last line if not exactly 16 characters.
    while ((i % 16) != 0) {
        printf ("   ");
        i++;
    }

    // And print the final ASCII bit.
    printf ("  %s\n", buff);
}



unsigned char *gen_rdm_bytestream (size_t num_bytes)
{
    srand ((unsigned int) time (NULL));
    unsigned char *stream = malloc (num_bytes);
    size_t i;

    for (i = 0; i < num_bytes; i++)
    {
        stream[i] = (unsigned char) rand ();
    }

    return stream;
}


bool is_folder_writable(char* str) {
    if(access(str, W_OK) == 0) {
        return true;
    } else {
        return false;
    }
}





