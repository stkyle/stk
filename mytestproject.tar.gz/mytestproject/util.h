//
// Created by root on 11/27/17.
//

#ifndef MYTESTPROJECT_UTIL_H
#define MYTESTPROJECT_UTIL_H

#include <glob.h>

#define false 0
#define true 1
#define bool int

bool isfile(const char *filename);
bool isreadable(const char *filename);

void handle_error(const char *msg);
void hexDump (char *desc, void *addr, int len);
unsigned char *gen_rdm_bytestream (size_t num_bytes);

#endif //MYTESTPROJECT_UTIL_H
