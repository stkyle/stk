//
// Created by root on 11/28/17.
//

#ifndef MYTESTPROJECT_TAKEFILE_H
#define MYTESTPROJECT_TAKEFILE_H

int dump_takefile(const char *filepath, unsigned char *blob, int blob_len,
                  char *pubkey_pem);

#endif //MYTESTPROJECT_TAKEFILE_H


