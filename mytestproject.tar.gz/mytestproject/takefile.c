//
// Created by root on 11/28/17.
//

#include <stdlib.h>
#include <stdio.h> //printf

#include "shrink.h"
#include "crypto.h"

#define TFILEBUF 100000000

int dump_takefile(const char *filepath,
                  unsigned char *blob,
                  int blob_len,
                  char *pubkey_pem){


    char *resolved_path = realpath(filepath, NULL);
    printf("[takefile] resolved_path: %s\n", resolved_path);

    // compress
    // create buffer for compressed blob
    unsigned char *blob_shrunk = (unsigned char *) malloc((size_t) blob_len);
    //unsigned char blob_shrunk[blob_len];
    int blob_len_new = shrink(blob, blob_len, blob_shrunk);
    //blob_len_new
    printf("blob_len_new: %d\n", blob_len_new);


    // encrypt
    unsigned char envelope[TFILEBUF];
    int envelope_size = encrypt(pubkey_pem, blob_shrunk, blob_len_new, envelope);



    // write to file
    FILE *f = fopen(resolved_path, "wb");
    fwrite(envelope, sizeof(unsigned char), (size_t) envelope_size, f);
    fclose(f);
    free(resolved_path);
    free(blob_shrunk);
    return 1;
}