//
// Created by root on 11/27/17.
//

#ifndef MYTESTPROJECT_CRYPTO_H
#define MYTESTPROJECT_CRYPTO_H
#include <openssl/evp.h>
#include <openssl/rsa.h>
void init_libcrypto(void);
void cleanup_openssl(void);
void handle_openssl_error(void);
EVP_PKEY * getPubKeyFromPemStr(char *key);
int envelope_seal(EVP_PKEY **pub_key, unsigned char *plaintext, int plaintext_len,
                  unsigned char **encrypted_key, int *encrypted_key_len, unsigned char *iv,
                  unsigned char *ciphertext);

int envelope_open(EVP_PKEY *priv_key, unsigned char *ciphertext, int ciphertext_len,
                  unsigned char *encrypted_key, int encrypted_key_len, unsigned char *iv,
                  unsigned char *plaintext);

RSA * load_pubkey(unsigned char * key);
RSA * getPubKeyFromText(unsigned char * key);
int public_encrypt(unsigned char * data, int data_len, RSA * pubkey, unsigned char *encrypted);
int encrypt(char *pubkey_pem, unsigned char *blob, int blob_len, unsigned char *envelope);


#endif //MYTESTPROJECT_CRYPTO_H

