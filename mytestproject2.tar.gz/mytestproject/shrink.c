//
// Created by root on 11/28/17.
//
#include <zlib.h>

#include "shrink.h"

#define CHUNK 16384

int shrink(unsigned char *blob, int blob_len, unsigned char *blob_shrunk) {

    // zlib initialize, allocate deflate state
    z_stream defstream;
    defstream.zalloc = Z_NULL;
    defstream.zfree = Z_NULL;
    defstream.opaque = Z_NULL;

    // setup input/output
    defstream.avail_in = (uInt) blob_len; // size of input
    defstream.next_in = (Bytef *) blob; // input array
    defstream.avail_out = (uInt) sizeof(blob_shrunk); // size of output
    defstream.next_out = (Bytef *) blob_shrunk; // output array

    // compression work.
    deflateInit(&defstream, Z_BEST_COMPRESSION);
    deflate(&defstream, Z_FINISH);
    deflateEnd(&defstream);

    // the size of the output
    return sizeof(blob_shrunk);


}