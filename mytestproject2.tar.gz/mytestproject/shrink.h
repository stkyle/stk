//
// Created by root on 11/28/17.
//

#ifndef MYTESTPROJECT_SHRINK_H
#define MYTESTPROJECT_SHRINK_H
int shrink(unsigned char *blob, int blob_len, unsigned char *blob_shrunk);

#endif //MYTESTPROJECT_SHRINK_H
