/*
 *
 * Generate Private Key (DER Format):
 *     $ openssl genpkey -algorithm RSA \
 *                 -pkeyopt rsa_keygen_bits:2048 \
 *                 -pkeyopt rsa_keygen_pubexp:65537 | \
 *                    openssl pkcs8 -topk8 -nocrypt \
 *                       -outform der > rsa-2048-private-key.p8
 *
 * Extracting the Public Key from the Private Key as a SubjectPublicKeyInfo (DER)
 *     $ openssl pkey -pubout -inform der -outform der \
 *                 -in rsa-2048-private-key.p8 \
 *                 -out rsa-2048-public-key.spki
 *
 * Extracting an RSA Public Key from the Private Key Without the SubjectPublicKeyInfo Metadata (DER)
 *     $ openssl pkey -pubout -inform der -outform der \
 *                 -in rsa-2048-private-key.p8 | \
 *                 openssl rsa -pubin -RSAPublicKey_out -inform DER -outform DER \
 *                 -out rsa-2048-public-key-legacy-form.der
 *
 * Extracting an RSA Public Key from the Private Key Without the SubjectPublicKeyInfo Metadata (PEM)
 *                 openssl pkey -pubout -inform der -outform der \
 *                 -in rsa-2048-private-key.p8 | \
 *                 openssl rsa -pubin -RSAPublicKey_out -inform DER -outform PEM \
 *                 -out rsa-2048-public-key-legacy-form.pem
 *
 */

#include <openssl/rand.h>
#include <openssl/crypto.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <stdio.h>
#include <openssl/pem.h> // PEM_read_bio_RSA_PUBKEY
#include <memory.h>

#include "util.h"
#include "crypto.h"

#define BUFSIZE 100000

void init_libcrypto(void) {

    /* Initialise the library */
    RAND_load_file("/dev/urandom", 1024);
    ERR_load_crypto_strings();  // registers the error strings for all libcrypto functions (remove for prod)
    //SSL_load_error_strings(); // registers the error strings for all libssl functions (remove for prod)
    //OpenSSL_add_all_algorithms();
    //OPENSSL_config(NULL);
}


void cleanup_openssl(void) {
    CRYPTO_cleanup_all_ex_data();
    ERR_free_strings();
    ERR_remove_thread_state(0);
    EVP_cleanup();
}

void handle_openssl_error(void) {
    ERR_print_errors_fp(stderr);
}


EVP_PKEY *getPubKeyFromPemStr(char *key) {
    RSA *rsa = NULL;
    BIO *keybio;
    keybio = BIO_new_mem_buf(key, -1);
    if (keybio == NULL) {
        printf("Failed to create key BIO");
        return 0;
    }
    rsa = PEM_read_bio_RSA_PUBKEY(keybio, &rsa, NULL, NULL);
    if (rsa == NULL) {
        printf("Failed to create RSA");
        return NULL;
    }
    EVP_PKEY *pubkey = EVP_PKEY_new();
    EVP_PKEY_set1_RSA(pubkey, rsa);
    return pubkey;
}

EVP_PKEY **malloc_pubkey_array_buf(int npubk) {
    return (EVP_PKEY **) malloc(sizeof(EVP_PKEY *) * npubk);
}

/*
 * ek is an array of buffers where the public key encrypted secret key will be written
 * each buffer must contain enough room for the corresponding encrypted key: that is ek[i] must have room for EVP_PKEY_size(pubk[i]) bytes.
 */
unsigned char **malloc_ek_array_buf(int nek) {
    return (unsigned char **) malloc(sizeof(unsigned char *) * nek);
}

/*
 * The actual size of each encrypted secret key is written to the array ekl
 */
int *malloc_ekl_array_buf(int nek) {
    return (int *) malloc(sizeof(int) * nek);
}

int encrypt(char *pubkey_pem, unsigned char *blob, int blob_len, unsigned char *envelope) {
    // load pub key into EVP struct
    EVP_PKEY *pubkey = getPubKeyFromPemStr(pubkey_pem);
    EVP_PKEY **pubkey_arr = malloc_pubkey_array_buf(1);
    pubkey_arr[0] = pubkey;

    unsigned char **ek = malloc_ek_array_buf(1);
    ek[0] = (unsigned char *) malloc((size_t) EVP_PKEY_size(pubkey_arr[0]));

    int *ekl = malloc_ekl_array_buf(1);

    unsigned char iv[16];

    unsigned char ciphertext[BUFSIZE];

    int cipher_len = envelope_seal(pubkey_arr, blob, blob_len, ek, ekl, iv, ciphertext);


    hexDump("Encrypted Key: \n", ek[0], ekl[0]);

    hexDump("IV: \n", &iv, sizeof(iv));

    hexDump("Cypher Text: ", &ciphertext, cipher_len);

    //
    int envelope_size = ekl[0] + (int) sizeof(iv) + cipher_len;
    //unsigned char envelope[envelope_size];

    //unsigned char *envelope = (unsigned char *) malloc(sizeof(unsigned char)*envelope_size);
    printf("Envelope Size: %d\n", (int) sizeof(envelope));


    // Copy bytes of first
    memcpy(envelope, ek[0], (size_t) ekl[0]);
    // Copy bytes of second immediately following bytes of first
    memcpy(&envelope[(int) ekl[0]], iv, 16);
    memcpy(&envelope[(int) ekl[0] + 16], ciphertext, (size_t) cipher_len);

    hexDump("envelope", envelope, envelope_size);

    //free(envelope);
    EVP_PKEY_free(pubkey);

    free(pubkey_arr);
    free(ek[0]);
    free(ek);
    return envelope_size;


}


/**
 *
 * @param pub_key Input Public Key
 * @param plaintext Input Data to Encrypt
 * @param plaintext_len Input Length of Data to Encrypt
 *
 * @param encrypted_key Output
 * @param encrypted_key_len Output
 * @param iv Output
 * @param ciphertext Output
 * @return Output
 */
int envelope_seal(EVP_PKEY **pub_key, unsigned char *plaintext, int plaintext_len,
                  unsigned char **encrypted_key, int *encrypted_key_len, unsigned char *iv,
                  unsigned char *ciphertext) {
    EVP_CIPHER_CTX *ctx;

    int ciphertext_len;

    int len;

    /* Create and initialise the context */
    if (!(ctx = EVP_CIPHER_CTX_new())) handle_error("unable to create cipher context");

    /* Initialise the envelope seal operation. This operation generates
     * a key for the provided cipher, and then encrypts that key a number
     * of times (one for each public key provided in the pub_key array). In
     * this example the array size is just one. This operation also
     * generates an IV and places it in iv. */
    if (1 != EVP_SealInit(ctx, EVP_aes_256_cbc(), encrypted_key,
                          encrypted_key_len, iv, pub_key, 1))
        handle_error("unable to Initialize EVP Seal");

    /* Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_SealUpdate can be called multiple times if necessary
     */
    if (1 != EVP_SealUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handle_error("unable to Update EVP Seal");
    ciphertext_len = len;

    /* Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if (1 != EVP_SealFinal(ctx, ciphertext + len, &len))
        handle_error("unable to Finalize EVP Seal");
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int envelope_open(EVP_PKEY *priv_key, unsigned char *ciphertext, int ciphertext_len,
                  unsigned char *encrypted_key, int encrypted_key_len, unsigned char *iv,
                  unsigned char *plaintext) {
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;


    /* Create and initialise the context */
    if (!(ctx = EVP_CIPHER_CTX_new())) handle_error("creating context");

    /* Initialise the decryption operation. The asymmetric private key is
     * provided and priv_key, whilst the encrypted session key is held in
     * encrypted_key */
    if (1 != EVP_OpenInit(ctx, EVP_aes_256_cbc(), encrypted_key,
                          encrypted_key_len, iv, priv_key))
        handle_error("initializing EVP_Open");

    /* Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_OpenUpdate can be called multiple times if necessary
     */
    if (1 != EVP_OpenUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handle_error("EVP Update");
    plaintext_len = len;

    /* Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if (1 != EVP_OpenFinal(ctx, plaintext + len, &len)) handle_error("Finalize");
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}


RSA *load_pubkey(unsigned char *key) {
    /* Read PEM Encoded Public Key from memory into an RSA Structure */
    RSA *rsa = NULL;
    BIO *keybio;
    keybio = BIO_new_mem_buf(key, -1);
    rsa = PEM_read_bio_RSA_PUBKEY(keybio, &rsa, NULL, NULL);
    return rsa;
}


RSA *getPubKeyFromText(unsigned char *key) {

    RSA *rsa = NULL;
    BIO *keybio;
    keybio = BIO_new_mem_buf(key, -1);
    if (keybio == NULL) {
        printf("Failed to create key BIO");
        return 0;
    }
    rsa = PEM_read_bio_RSA_PUBKEY(keybio, &rsa, NULL, NULL);
    if (rsa == NULL) {
        printf("Failed to create RSA");
    }

    return rsa;
}



