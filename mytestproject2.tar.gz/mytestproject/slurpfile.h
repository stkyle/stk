//
// Created by root on 11/27/17.
//

#ifndef MYTESTPROJECT_SLURPFILE_H
#define MYTESTPROJECT_SLURPFILE_H

long slurpfile(char const* path, char **buf, int add_nul);

#endif //MYTESTPROJECT_SLURPFILE_H
